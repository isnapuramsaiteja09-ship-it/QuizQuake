# QuizQuake — BrainStorm Arena

A vibrant, animated adaptive Computer Science quiz and topic-assignment platform built for the **QuizQuake: BrainStorm Arena** brief.

## Features Implemented

- **Vibrant Animated UI & Motion System:** Aurora background blobs, glassmorphism cards, animated gradient accents, smooth tab/stage entrance choreography, staggered answer option reveals, interactive hover/tap spring physics, animated progress bars, and celebratory pass badges.
- **Topic Assignment Studio:** Select any Computer Science topic (*Data Structures*, *Algorithms*, *Operating Systems*, *Computer Networks*, or *All Topics*), choose a difficulty tier (*All*, *Easy*, *Medium*, *Hard*), set custom question count and time limits, flag questions during the test, use keyboard shortcuts (`1`–`4`), review explanations, save history in `localStorage`, and export PDF assignment reports.
- **Adaptive Arena Mode:** Two consecutive correct answers promote difficulty (`Easy → Medium → Hard`); an incorrect answer drops a tier (`Hard → Medium → Easy`) with balanced topic rotation.
- **60 Curated MCQs:** 15 questions each across *Data Structures*, *Algorithms*, *Operating Systems*, and *Computer Networks* (5 Easy, 5 Medium, 5 Hard per topic).
- **Custom Question Bank Builder:** Add your own topic-tagged questions right in the browser (persisted in `localStorage`) to expand assignments on the fly.
- **Diagnostics & Analytics:** Topic mastery breakdown, streak multipliers, and downloadable PDF reports via `jsPDF`.

## Run Locally

Install Node.js 20+ and npm:

```bash
npm install
npm run dev
```

Open **http://localhost:5173**. The Vite dev server proxies `/api` requests to the Express server on `http://localhost:4000`.
