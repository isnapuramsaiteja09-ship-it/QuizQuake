import React, { useEffect, useMemo, useState } from 'react';
import {
  Award,
  Bookmark,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  Play,
  RotateCcw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { AttemptSummary, Difficulty, Question, QuizAnswerRecord } from '../types';
import { exportAttemptPdf, getDifficultyThemeClass, getTopicThemeClass } from '../utils';

interface Props {
  questions: Question[];
  history: AttemptSummary[];
  onSaveAttempt: (attempt: AttemptSummary) => void;
}

type Stage = 'builder' | 'active' | 'report';

export const TopicAssignmentView: React.FC<Props> = ({ questions, history, onSaveAttempt }) => {
  const topics = useMemo(() => {
    return Array.from(new Set(questions.map((q) => q.topic)));
  }, [questions]);

  const [title, setTitle] = useState('Topic Mastery Assignment');
  const [selectedTopic, setSelectedTopic] = useState<string>(topics[0] || 'Data Structures');
  const [selectedTier, setSelectedTier] = useState<'All' | Difficulty>('All');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [minutes, setMinutes] = useState<number>(5);

  useEffect(() => {
    if (topics.length > 0 && !topics.includes(selectedTopic) && selectedTopic !== 'All') {
      setSelectedTopic(topics[0]);
    }
  }, [topics, selectedTopic]);

  const [stage, setStage] = useState<Stage>('builder');
  const [deck, setDeck] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedMap, setSelectedMap] = useState<Record<string, number>>({});
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(300);
  const [latestReport, setLatestReport] = useState<AttemptSummary | null>(null);
  const [onlyFlagged, setOnlyFlagged] = useState(false);

  const matchingPool = useMemo(() => {
    return questions.filter((q) => {
      const tOk = selectedTopic === 'All' || q.topic === selectedTopic;
      const dOk = selectedTier === 'All' || q.difficulty === selectedTier;
      return tOk && dOk;
    });
  }, [questions, selectedTopic, selectedTier]);

  const startAssignment = () => {
    let pool = [...matchingPool];
    if (pool.length === 0 && selectedTopic !== 'All') {
      pool = questions.filter((q) => q.topic === selectedTopic);
    }
    if (pool.length === 0) {
      pool = [...questions];
    }

    const shuffled = pool.sort(() => Math.random() - 0.5);
    const chosen = shuffled.slice(0, Math.max(1, Math.min(questionCount, shuffled.length)));

    setDeck(chosen);
    setCurrentIdx(0);
    setSelectedMap({});
    setBookmarkedIds([]);
    setSecondsLeft(Math.max(30, minutes * 60));
    setOnlyFlagged(false);
    setStage('active');
  };

  const submitAssignment = () => {
    let streak = 0;
    let bestStreak = 0;
    let score = 0;

    const records: QuizAnswerRecord[] = deck.map((q) => {
      const picked = selectedMap[q.id] ?? null;
      const isCorrect = picked === q.correctIndex;
      if (isCorrect) {
        streak += 1;
        bestStreak = Math.max(bestStreak, streak);
        const tierMult = q.difficulty === 'Hard' ? 1.5 : q.difficulty === 'Medium' ? 1.25 : 1;
        score += Math.round(100 * tierMult + (streak - 1) * 20);
      } else {
        streak = 0;
      }

      return {
        questionId: q.id,
        topic: q.topic,
        subtopic: q.subtopic,
        difficulty: q.difficulty,
        question: q.question,
        options: q.options,
        selectedIndex: picked,
        correctIndex: q.correctIndex,
        isCorrect,
        explanation: q.explanation,
        timeSpentSec: 0,
      };
    });

    const correctCount = records.filter((r) => r.isCorrect).length;
    const totalCount = records.length;
    const accuracyPercent = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;

    const attempt: AttemptSummary = {
      id: `assign-${Date.now()}`,
      mode: 'assignment',
      title: title.trim() || `${selectedTopic} Assignment`,
      topicFilter: selectedTopic === 'All' ? 'All Topics' : `${selectedTopic} (${selectedTier})`,
      completedAt: new Date().toLocaleString(),
      score,
      correctCount,
      totalCount,
      accuracyPercent,
      passed: accuracyPercent >= 70,
      bestStreak,
      bookmarkedIds,
      records,
    };

    setLatestReport(attempt);
    onSaveAttempt(attempt);
    setStage('report');
  };

  useEffect(() => {
    if (stage !== 'active') return;
    if (secondsLeft <= 0) {
      submitAssignment();
      return;
    }
    const timer = window.setInterval(() => setSecondsLeft((s) => s - 1), 1000);
    return () => window.clearInterval(timer);
  }, [stage, secondsLeft]);

  const currentQuestion = deck[currentIdx];

  useEffect(() => {
    if (stage !== 'active' || !currentQuestion) return;
    const onKey = (e: KeyboardEvent) => {
      const n = Number(e.key);
      if (n >= 1 && n <= currentQuestion.options.length) {
        setSelectedMap((prev) => ({ ...prev, [currentQuestion.id]: n - 1 }));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [stage, currentQuestion]);

  const toggleBookmark = (id: string) => {
    setBookmarkedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const assignmentHistory = history.filter((h) => h.mode === 'assignment');

  const formatTime = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const answeredCount = Object.keys(selectedMap).length;

  return (
    <div className="card animate-stage">
      <div className="row-between" style={{ marginBottom: '1.1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div className="icon-badge gradient-violet">
            <FileText size={20} />
          </div>
          <div>
            <h2 style={{ margin: 0 }}>Topic Assignment Studio</h2>
            <span className="muted" style={{ fontSize: '0.86rem' }}>
              Curated topic drills with instant evaluation &amp; PDF transcripts
            </span>
          </div>
        </div>
        {stage !== 'builder' && (
          <button type="button" className="btn btn-secondary" onClick={() => setStage('builder')}>
            Configure New Assignment
          </button>
        )}
      </div>

      {stage === 'builder' && (
        <div className="animate-fade-up">
          <div className="topic-chip-row">
            <button
              type="button"
              className={`topic-chip ${selectedTopic === 'All' ? 'active topic-custom' : ''}`}
              onClick={() => setSelectedTopic('All')}
            >
              <Sparkles size={14} /> All Topics ({questions.length})
            </button>
            {topics.map((t) => {
              const count = questions.filter((q) => q.topic === t).length;
              return (
                <button
                  key={t}
                  type="button"
                  className={`topic-chip ${getTopicThemeClass(t)} ${selectedTopic === t ? 'active' : ''}`}
                  onClick={() => setSelectedTopic(t)}
                >
                  {t} ({count})
                </button>
              );
            })}
          </div>

          <div className="form-grid" style={{ marginTop: '1.1rem' }}>
            <label className="field">
              <span>Assignment Title</span>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Operating Systems Midterm Practice"
              />
            </label>

            <label className="field">
              <span>Selected Topic</span>
              <select value={selectedTopic} onChange={(e) => setSelectedTopic(e.target.value)}>
                <option value="All">All Topics (Mixed)</option>
                {topics.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </label>

            <label className="field">
              <span>Difficulty Tier</span>
              <select
                value={selectedTier}
                onChange={(e) => setSelectedTier(e.target.value as 'All' | Difficulty)}
              >
                <option value="All">All Tiers (Easy, Medium, Hard)</option>
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
              </select>
            </label>

            <label className="field">
              <span>Questions ({matchingPool.length} available)</span>
              <input
                type="number"
                min={1}
                max={Math.max(1, questions.length)}
                value={questionCount}
                onChange={(e) => setQuestionCount(Math.max(1, Number(e.target.value)))}
              />
            </label>

            <label className="field">
              <span>Time Limit (Minutes)</span>
              <input
                type="number"
                min={1}
                max={60}
                value={minutes}
                onChange={(e) => setMinutes(Math.max(1, Number(e.target.value)))}
              />
            </label>
          </div>

          <div style={{ marginTop: '1.35rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
            <button type="button" className="btn btn-primary btn-glow" onClick={startAssignment}>
              <Play size={16} /> Start Topic Assignment
            </button>
            <span className="muted" style={{ fontSize: '0.9rem' }}>
              Pass threshold: <strong>70%</strong> • Press keys <strong>1–4</strong> to pick answers fast
            </span>
          </div>

          {assignmentHistory.length > 0 && (
            <div style={{ marginTop: '2rem' }}>
              <h3>Past Topic Assignments</h3>
              <div className="stack-sm">
                {assignmentHistory.map((item, idx) => (
                  <div
                    key={item.id}
                    className="history-item animate-stagger"
                    style={{ animationDelay: `${idx * 60}ms` }}
                  >
                    <div>
                      <strong>{item.title}</strong> — <span className="badge badge-indigo">{item.topicFilter}</span>
                      <div className="muted" style={{ fontSize: '0.82rem', marginTop: '0.2rem' }}>
                        {item.completedAt}
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span>
                        <strong>{item.accuracyPercent}%</strong> ({item.correctCount}/{item.totalCount}) •{' '}
                        <span className={item.passed ? 'status-pass' : 'status-review'}>
                          {item.passed ? 'Passed' : 'Needs Review'}
                        </span>
                      </span>
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={() => exportAttemptPdf(item)}
                      >
                        <Download size={14} /> PDF
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {stage === 'active' && currentQuestion && (
        <div key={currentQuestion.id} className="animate-question-swap">
          <div className="row-between" style={{ marginBottom: '0.75rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
              <strong>{title}</strong>
              <span className={`badge ${getTopicThemeClass(currentQuestion.topic)}`}>
                {currentQuestion.topic}
              </span>
              <span className={`badge ${getDifficultyThemeClass(currentQuestion.difficulty)}`}>
                {currentQuestion.difficulty}
              </span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <span className={`timer-pill ${secondsLeft <= 30 ? 'timer-urgent' : ''}`}>
                <Clock size={15} /> {formatTime(secondsLeft)}
              </span>
              <button
                type="button"
                className={`btn btn-sm ${bookmarkedIds.includes(currentQuestion.id) ? 'btn-warn' : 'btn-secondary'}`}
                onClick={() => toggleBookmark(currentQuestion.id)}
              >
                <Bookmark size={14} />
                {bookmarkedIds.includes(currentQuestion.id) ? 'Flagged' : 'Flag'}
              </button>
            </div>
          </div>

          <div className="live-progress-bar">
            <div
              className="live-progress-fill"
              style={{ width: `${Math.round((answeredCount / Math.max(1, deck.length)) * 100)}%` }}
            />
          </div>

          <div className="pill-nav">
            {deck.map((q, i) => {
              const answered = selectedMap[q.id] !== undefined;
              const flagged = bookmarkedIds.includes(q.id);
              return (
                <button
                  key={q.id}
                  type="button"
                  onClick={() => setCurrentIdx(i)}
                  className={`nav-pill ${i === currentIdx ? 'active' : ''} ${answered ? 'answered' : ''} ${flagged ? 'flagged' : ''}`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          <h3 className="question-heading">
            <span className="q-num">Q{currentIdx + 1}</span> {currentQuestion.question}
          </h3>

          <div className="stack-sm">
            {currentQuestion.options.map((opt, idx) => {
              const chosen = selectedMap[currentQuestion.id] === idx;
              return (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setSelectedMap((prev) => ({ ...prev, [currentQuestion.id]: idx }))}
                  className={`option-btn animate-stagger ${chosen ? 'selected' : ''}`}
                  style={{ animationDelay: `${idx * 55}ms` }}
                >
                  <span className="opt-key">{idx + 1}</span>
                  <span>{opt}</span>
                </button>
              );
            })}
          </div>

          <div className="row-between" style={{ marginTop: '1.4rem' }}>
            <button
              type="button"
              className="btn btn-secondary"
              disabled={currentIdx === 0}
              onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
            >
              Previous
            </button>

            <div style={{ display: 'flex', gap: '0.6rem' }}>
              {currentIdx + 1 < deck.length && (
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setCurrentIdx((i) => Math.min(deck.length - 1, i + 1))}
                >
                  Next
                </button>
              )}
              <button type="button" className="btn btn-success btn-glow" onClick={submitAssignment}>
                Submit Assignment
              </button>
            </div>
          </div>
        </div>
      )}

      {stage === 'report' && latestReport && (
        <div className="animate-fade-up">
          <div className={`report-hero ${latestReport.passed ? 'hero-pass' : 'hero-review'}`}>
            <div className="row-between">
              <div>
                <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <Award size={22} /> {latestReport.title} — Evaluation Report
                </h3>
                <p style={{ margin: '0.4rem 0 0', opacity: 0.92 }}>
                  Topic: <strong>{latestReport.topicFilter}</strong> • Score: <strong>{latestReport.score} pts</strong> • Accuracy:{' '}
                  <strong>
                    {latestReport.correctCount}/{latestReport.totalCount} ({latestReport.accuracyPercent}%)
                  </strong>{' '}
                  • Status: <strong>{latestReport.passed ? 'PASSED' : 'NEEDS REVIEW'}</strong>
                </p>
              </div>

              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => setOnlyFlagged((f) => !f)}
                >
                  {onlyFlagged ? 'Show All' : `Flagged (${latestReport.bookmarkedIds?.length || 0})`}
                </button>
                <button
                  type="button"
                  className="btn btn-secondary btn-sm"
                  onClick={() => exportAttemptPdf(latestReport)}
                >
                  <Download size={14} /> Export PDF
                </button>
                <button type="button" className="btn btn-primary btn-sm" onClick={startAssignment}>
                  <RotateCcw size={14} /> Retry
                </button>
              </div>
            </div>
          </div>

          <div className="stack-sm" style={{ marginTop: '1.1rem' }}>
            {latestReport.records
              .filter((r) => !onlyFlagged || latestReport.bookmarkedIds?.includes(r.questionId))
              .map((rec, i) => (
                <div
                  key={rec.questionId}
                  className={`review-card animate-stagger ${rec.isCorrect ? 'correct' : 'incorrect'}`}
                  style={{ animationDelay: `${i * 65}ms` }}
                >
                  <div className="row-between">
                    <strong>
                      {i + 1}. {rec.question}
                    </strong>
                    {rec.isCorrect ? (
                      <CheckCircle2 size={19} color="#059669" />
                    ) : (
                      <XCircle size={19} color="#e11d48" />
                    )}
                  </div>
                  <p style={{ margin: '0.4rem 0 0.2rem', fontSize: '0.92rem' }}>
                    Your Answer:{' '}
                    <strong>{rec.selectedIndex !== null ? rec.options[rec.selectedIndex] : 'Unanswered'}</strong> | Correct:{' '}
                    <strong>{rec.options[rec.correctIndex]}</strong>
                  </p>
                  <p className="muted" style={{ margin: 0, fontSize: '0.88rem' }}>
                    {rec.explanation}
                  </p>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
};
