import React, { useState } from 'react';
import { PlusCircle, Sparkles } from 'lucide-react';
import { Difficulty, Question } from '../types';

interface Props {
  existingTopics: string[];
  onAddQuestion: (q: Question) => void;
}

export const QuestionBankManager: React.FC<Props> = ({ existingTopics, onAddQuestion }) => {
  const [topic, setTopic] = useState(existingTopics[0] || 'Data Structures');
  const [customTopic, setCustomTopic] = useState('');
  const [subtopic, setSubtopic] = useState('Core Concepts');
  const [difficulty, setDifficulty] = useState<Difficulty>('Medium');
  const [prompt, setPrompt] = useState('');
  const [opt0, setOpt0] = useState('');
  const [opt1, setOpt1] = useState('');
  const [opt2, setOpt2] = useState('');
  const [opt3, setOpt3] = useState('');
  const [correctIndex, setCorrectIndex] = useState(0);
  const [explanation, setExplanation] = useState('');
  const [savedBanner, setSavedBanner] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const resolvedTopic = customTopic.trim() || topic;
    const options = [opt0.trim(), opt1.trim(), opt2.trim(), opt3.trim()];
    if (!resolvedTopic || !prompt.trim() || options.some((o) => !o)) return;

    const newQuestion: Question = {
      id: `custom-${Date.now()}`,
      topic: resolvedTopic,
      subtopic: subtopic.trim() || 'General',
      difficulty,
      question: prompt.trim(),
      options,
      correctIndex,
      explanation: explanation.trim() || 'Custom question added to your QuizQuake bank.',
    };

    onAddQuestion(newQuestion);
    setPrompt('');
    setOpt0('');
    setOpt1('');
    setOpt2('');
    setOpt3('');
    setExplanation('');
    setSavedBanner(true);
    window.setTimeout(() => setSavedBanner(false), 3200);
  };

  return (
    <div className="card animate-stage">
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.75rem' }}>
        <div className="icon-badge gradient-emerald">
          <PlusCircle size={20} />
        </div>
        <div>
          <h2 style={{ margin: 0 }}>Add Custom Topic Question</h2>
          <span className="muted" style={{ fontSize: '0.86rem' }}>
            Expand your question repository with custom subjects &amp; explanations
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="animate-fade-up">
        <div className="form-grid">
          <label className="field">
            <span>Existing Topic</span>
            <select value={topic} onChange={(e) => setTopic(e.target.value)}>
              {existingTopics.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </label>

          <label className="field">
            <span>Or New Topic Name (Optional)</span>
            <input
              type="text"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              placeholder="e.g. Database Systems"
            />
          </label>

          <label className="field">
            <span>Subtopic</span>
            <input
              type="text"
              value={subtopic}
              onChange={(e) => setSubtopic(e.target.value)}
              placeholder="e.g. Indexing & SQL"
            />
          </label>

          <label className="field">
            <span>Difficulty</span>
            <select value={difficulty} onChange={(e) => setDifficulty(e.target.value as Difficulty)}>
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </label>
        </div>

        <label className="field" style={{ marginTop: '0.95rem' }}>
          <span>Question Prompt</span>
          <input
            type="text"
            required
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Enter the question text..."
          />
        </label>

        <div className="form-grid" style={{ marginTop: '0.95rem' }}>
          <label className="field">
            <span>Option 1</span>
            <input type="text" required value={opt0} onChange={(e) => setOpt0(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 2</span>
            <input type="text" required value={opt1} onChange={(e) => setOpt1(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 3</span>
            <input type="text" required value={opt2} onChange={(e) => setOpt2(e.target.value)} />
          </label>
          <label className="field">
            <span>Option 4</span>
            <input type="text" required value={opt3} onChange={(e) => setOpt3(e.target.value)} />
          </label>
        </div>

        <div className="form-grid" style={{ marginTop: '0.95rem' }}>
          <label className="field">
            <span>Correct Option</span>
            <select value={correctIndex} onChange={(e) => setCorrectIndex(Number(e.target.value))}>
              <option value={0}>Option 1</option>
              <option value={1}>Option 2</option>
              <option value={2}>Option 3</option>
              <option value={3}>Option 4</option>
            </select>
          </label>

          <label className="field">
            <span>Explanation</span>
            <input
              type="text"
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              placeholder="Why is this answer correct?"
            />
          </label>
        </div>

        <div style={{ marginTop: '1.2rem', display: 'flex', alignItems: 'center', gap: '1rem', flexWrap: 'wrap' }}>
          <button type="submit" className="btn btn-primary btn-glow">
            <Sparkles size={16} /> Save Question to Bank
          </button>
          {savedBanner && (
            <span className="toast-pill">Saved! Ready in Topic Assignment Studio.</span>
          )}
        </div>
      </form>
    </div>
  );
};
