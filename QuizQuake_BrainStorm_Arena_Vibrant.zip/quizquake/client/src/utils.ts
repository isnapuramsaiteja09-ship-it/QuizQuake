import { jsPDF } from 'jspdf';
import { AttemptSummary, Difficulty, Question } from './types';

export const HISTORY_STORAGE_KEY = 'quizquake_attempt_history_v1';

export function loadAttemptHistory(): AttemptSummary[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as AttemptSummary[]) : [];
  } catch {
    return [];
  }
}

export function saveAttempt(attempt: AttemptSummary): AttemptSummary[] {
  const updated = [attempt, ...loadAttemptHistory()].slice(0, 20);
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // Ignore storage errors
  }
  return updated;
}

export function nextDifficulty(
  current: Difficulty,
  consecutiveCorrect: number,
  wasCorrect: boolean
): Difficulty {
  if (!wasCorrect) {
    if (current === 'Hard') return 'Medium';
    return 'Easy';
  }
  if (consecutiveCorrect >= 2) {
    if (current === 'Easy') return 'Medium';
    return 'Hard';
  }
  return current;
}

export function pickNextAdaptiveQuestion(
  all: Question[],
  usedIds: Set<string>,
  targetDifficulty: Difficulty,
  preferredTopic?: string
): Question | null {
  const unused = all.filter((q) => !usedIds.has(q.id));
  if (unused.length === 0) return null;

  const exact = unused.filter(
    (q) => q.difficulty === targetDifficulty && (!preferredTopic || q.topic === preferredTopic)
  );
  if (exact.length > 0) return exact[Math.floor(Math.random() * exact.length)];

  const diffOnly = unused.filter((q) => q.difficulty === targetDifficulty);
  if (diffOnly.length > 0) return diffOnly[Math.floor(Math.random() * diffOnly.length)];

  return unused[Math.floor(Math.random() * unused.length)];
}

export function getTopicThemeClass(topic: string): string {
  const t = topic.toLowerCase();
  if (t.includes('data')) return 'topic-ds';
  if (t.includes('algo')) return 'topic-algo';
  if (t.includes('operating') || t.includes('os')) return 'topic-os';
  if (t.includes('network')) return 'topic-net';
  return 'topic-custom';
}

export function getDifficultyThemeClass(diff: Difficulty): string {
  if (diff === 'Easy') return 'diff-easy';
  if (diff === 'Medium') return 'diff-medium';
  return 'diff-hard';
}

export function exportAttemptPdf(attempt: AttemptSummary): void {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text('QuizQuake — BrainStorm Arena Report', 14, 18);

  doc.setFontSize(11);
  doc.text(`Title: ${attempt.title} (${attempt.mode.toUpperCase()})`, 14, 28);
  doc.text(`Topic: ${attempt.topicFilter} | Completed: ${attempt.completedAt}`, 14, 35);
  doc.text(
    `Score: ${attempt.score} pts | Accuracy: ${attempt.correctCount}/${attempt.totalCount} (${attempt.accuracyPercent}%) — ${attempt.passed ? 'PASSED' : 'NEEDS REVIEW'}`,
    14,
    42
  );

  let y = 54;
  attempt.records.forEach((rec, i) => {
    if (y > 265) {
      doc.addPage();
      y = 20;
    }
    const tag = rec.isCorrect ? '[CORRECT]' : '[INCORRECT]';
    const userAns = rec.selectedIndex !== null ? rec.options[rec.selectedIndex] : 'Unanswered';
    const rightAns = rec.options[rec.correctIndex];

    doc.setFontSize(10);
    const lines = doc.splitTextToSize(`${i + 1}. ${tag} (${rec.topic} - ${rec.difficulty}) ${rec.question}`, 180);
    doc.text(lines, 14, y);
    y += lines.length * 5;

    doc.text(`   Your Answer: ${userAns} | Correct: ${rightAns}`, 14, y);
    y += 8;
  });

  doc.save(`quizquake-${attempt.mode}-report.pdf`);
}
