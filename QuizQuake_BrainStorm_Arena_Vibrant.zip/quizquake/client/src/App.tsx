import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart3,
  Brain,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  Flame,
  PlusCircle,
  Sparkles,
  Zap,
} from 'lucide-react';
import { fetchAllQuestions, saveCustomQuestion } from './api';
import { QuestionBankManager } from './components/QuestionBankManager';
import { TopicAssignmentView } from './components/TopicAssignmentView';
import { AttemptSummary, Difficulty, Question, QuizAnswerRecord } from './types';
import {
  exportAttemptPdf,
  getDifficultyThemeClass,
  getTopicThemeClass,
  loadAttemptHistory,
  nextDifficulty,
  pickNextAdaptiveQuestion,
  saveAttempt,
} from './utils';

type Tab = 'assignment' | 'adaptive' | 'diagnostics' | 'builder';

export default function App() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<Tab>('assignment');
  const [history, setHistory] = useState<AttemptSummary[]>(() => loadAttemptHistory());

  // Adaptive Arena state
  const [arenaRunning, setArenaRunning] = useState(false);
  const [arenaQuestion, setArenaQuestion] = useState<Question | null>(null);
  const [arenaUsedIds, setArenaUsedIds] = useState<Set<string>>(new Set());
  const [arenaDifficulty, setArenaDifficulty] = useState<Difficulty>('Easy');
  const [arenaStreak, setArenaStreak] = useState(0);
  const [arenaBestStreak, setArenaBestStreak] = useState(0);
  const [arenaScore, setArenaScore] = useState(0);
  const [arenaRecords, setArenaRecords] = useState<QuizAnswerRecord[]>([]);
  const [arenaSelected, setArenaSelected] = useState<number | null>(null);
  const [arenaTimeLeft, setArenaTimeLeft] = useState(600);
  const [arenaFinishedAttempt, setArenaFinishedAttempt] = useState<AttemptSummary | null>(null);

  useEffect(() => {
    fetchAllQuestions().then((data) => {
      setQuestions(data);
      setLoading(false);
    });
  }, []);

  const topics = useMemo(() => Array.from(new Set(questions.map((q) => q.topic))), [questions]);

  const handleRecordAttempt = (attempt: AttemptSummary) => {
    setHistory(saveAttempt(attempt));
  };

  const handleAddCustomQuestion = (q: Question) => {
    saveCustomQuestion(q);
    setQuestions((prev) => [q, ...prev]);
  };

  const startAdaptiveArena = () => {
    const used = new Set<string>();
    const first = pickNextAdaptiveQuestion(questions, used, 'Easy', topics[0]);
    if (!first) return;
    used.add(first.id);

    setArenaUsedIds(used);
    setArenaQuestion(first);
    setArenaDifficulty('Easy');
    setArenaStreak(0);
    setArenaBestStreak(0);
    setArenaScore(0);
    setArenaRecords([]);
    setArenaSelected(null);
    setArenaTimeLeft(600);
    setArenaFinishedAttempt(null);
    setArenaRunning(true);
  };

  const finishAdaptiveArena = (finalRecords: QuizAnswerRecord[], finalScore: number, bestStreak: number) => {
    setArenaRunning(false);
    const correctCount = finalRecords.filter((r) => r.isCorrect).length;
    const totalCount = finalRecords.length;
    const accuracyPercent = totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;

    const summary: AttemptSummary = {
      id: `arena-${Date.now()}`,
      mode: 'adaptive',
      title: 'Adaptive BrainStorm Arena',
      topicFilter: 'Adaptive Multi-Topic',
      completedAt: new Date().toLocaleString(),
      score: finalScore,
      correctCount,
      totalCount,
      accuracyPercent,
      passed: accuracyPercent >= 70,
      bestStreak,
      records: finalRecords,
    };

    setArenaFinishedAttempt(summary);
    handleRecordAttempt(summary);
  };

  useEffect(() => {
    if (!arenaRunning) return;
    if (arenaTimeLeft <= 0) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }
    const id = window.setInterval(() => setArenaTimeLeft((t) => t - 1), 1000);
    return () => window.clearInterval(id);
  }, [arenaRunning, arenaTimeLeft, arenaRecords, arenaScore, arenaBestStreak]);

  const answerAdaptive = (optIdx: number) => {
    if (!arenaQuestion || arenaSelected !== null) return;
    setArenaSelected(optIdx);

    const isCorrect = optIdx === arenaQuestion.correctIndex;
    const newStreak = isCorrect ? arenaStreak + 1 : 0;
    const newBest = Math.max(arenaBestStreak, newStreak);
    const tierPts = arenaQuestion.difficulty === 'Hard' ? 150 : arenaQuestion.difficulty === 'Medium' ? 120 : 100;
    const gained = isCorrect ? tierPts + (newStreak - 1) * 25 : 0;

    setArenaStreak(newStreak);
    setArenaBestStreak(newBest);
    setArenaScore((s) => s + gained);

    const rec: QuizAnswerRecord = {
      questionId: arenaQuestion.id,
      topic: arenaQuestion.topic,
      subtopic: arenaQuestion.subtopic,
      difficulty: arenaQuestion.difficulty,
      question: arenaQuestion.question,
      options: arenaQuestion.options,
      selectedIndex: optIdx,
      correctIndex: arenaQuestion.correctIndex,
      isCorrect,
      explanation: arenaQuestion.explanation,
      timeSpentSec: 0,
    };
    setArenaRecords((prev) => [...prev, rec]);
  };

  const nextAdaptiveStep = () => {
    if (!arenaQuestion) return;
    const lastCorrect = arenaSelected === arenaQuestion.correctIndex;
    const nextDiff = nextDifficulty(arenaDifficulty, arenaStreak, lastCorrect);
    const nextTopic = topics[arenaRecords.length % Math.max(1, topics.length)];

    if (arenaRecords.length >= 10) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }

    const nextQ = pickNextAdaptiveQuestion(questions, arenaUsedIds, nextDiff, nextTopic);
    if (!nextQ) {
      finishAdaptiveArena(arenaRecords, arenaScore, arenaBestStreak);
      return;
    }

    const updatedUsed = new Set(arenaUsedIds);
    updatedUsed.add(nextQ.id);
    setArenaUsedIds(updatedUsed);
    setArenaDifficulty(nextDiff);
    setArenaQuestion(nextQ);
    setArenaSelected(null);
  };

  const topicStats = useMemo(() => {
    const map: Record<string, { correct: number; total: number }> = {};
    for (const t of topics) map[t] = { correct: 0, total: 0 };

    for (const att of history) {
      for (const r of att.records) {
        if (!map[r.topic]) map[r.topic] = { correct: 0, total: 0 };
        map[r.topic].total += 1;
        if (r.isCorrect) map[r.topic].correct += 1;
      }
    }

    return Object.entries(map).map(([topicName, val]) => ({
      topic: topicName,
      correct: val.correct,
      total: val.total,
      pct: val.total > 0 ? Math.round((val.correct / val.total) * 100) : 0,
    }));
  }, [history, topics]);

  return (
    <div className="app-shell">
      <div className="bg-aurora" aria-hidden="true">
        <span className="orb orb-1" />
        <span className="orb orb-2" />
        <span className="orb orb-3" />
      </div>

      <header className="topbar">
        <div className="brand">
          <div className="logo-pulse">
            <Brain size={28} />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
              <h1>QuizQuake: BrainStorm Arena</h1>
              <span className="live-chip">
                <Sparkles size={12} /> {questions.length} MCQs
              </span>
            </div>
            <p>Vibrant Adaptive CS Assessment &amp; Topic Assignment Studio</p>
          </div>
        </div>

        <nav className="tabs">
          <button
            type="button"
            className={`tab-btn ${tab === 'assignment' ? 'active' : ''}`}
            onClick={() => setTab('assignment')}
          >
            <FileText size={16} /> Topic Assignments
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'adaptive' ? 'active' : ''}`}
            onClick={() => setTab('adaptive')}
          >
            <Zap size={16} /> Adaptive Arena
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'diagnostics' ? 'active' : ''}`}
            onClick={() => setTab('diagnostics')}
          >
            <BarChart3 size={16} /> Mastery &amp; History
          </button>
          <button
            type="button"
            className={`tab-btn ${tab === 'builder' ? 'active' : ''}`}
            onClick={() => setTab('builder')}
          >
            <PlusCircle size={16} /> Add Questions
          </button>
        </nav>
      </header>

      <main className="container">
        {loading ? (
          <div className="card animate-stage">
            <div className="shimmer-loader">Loading your Computer Science question bank...</div>
          </div>
        ) : (
          <>
            {tab === 'assignment' && (
              <TopicAssignmentView
                questions={questions}
                history={history}
                onSaveAttempt={handleRecordAttempt}
              />
            )}

            {tab === 'adaptive' && (
              <div className="card animate-stage">
                <div className="row-between" style={{ marginBottom: '1rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                    <div className="icon-badge gradient-amber">
                      <Zap size={20} />
                    </div>
                    <div>
                      <h2 style={{ margin: 0 }}>Adaptive BrainStorm Arena</h2>
                      <p className="muted" style={{ margin: '0.2rem 0 0', fontSize: '0.88rem' }}>
                        2 consecutive correct answers promote tier (Easy → Medium → Hard); 1 miss drops a tier.
                      </p>
                    </div>
                  </div>
                  {!arenaRunning && (
                    <button type="button" className="btn btn-primary btn-glow" onClick={startAdaptiveArena}>
                      <Zap size={16} /> Start 10-Question Adaptive Run
                    </button>
                  )}
                </div>

                {arenaRunning && arenaQuestion && (
                  <div key={arenaQuestion.id} className="animate-question-swap">
                    <div className="row-between" style={{ marginBottom: '1rem' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.45rem', flexWrap: 'wrap' }}>
                        <strong>Question {arenaRecords.length + 1}/10</strong>
                        <span className={`badge ${getTopicThemeClass(arenaQuestion.topic)}`}>
                          {arenaQuestion.topic}
                        </span>
                        <span className={`badge ${getDifficultyThemeClass(arenaQuestion.difficulty)}`}>
                          {arenaQuestion.difficulty}
                        </span>
                      </div>
                      <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', flexWrap: 'wrap' }}>
                        <span className="timer-pill">
                          <Clock size={14} /> {Math.floor(arenaTimeLeft / 60)}:
                          {(arenaTimeLeft % 60).toString().padStart(2, '0')}
                        </span>
                        <span className={`streak-pill ${arenaStreak >= 2 ? 'streak-hot' : ''}`}>
                          <Flame size={15} /> Streak: <strong>{arenaStreak}</strong>
                        </span>
                        <span className="score-pill">
                          Score: <strong>{arenaScore}</strong>
                        </span>
                      </div>
                    </div>

                    <h3 className="question-heading">{arenaQuestion.question}</h3>

                    <div className="stack-sm">
                      {arenaQuestion.options.map((opt, idx) => {
                        let extra = '';
                        if (arenaSelected !== null) {
                          if (idx === arenaQuestion.correctIndex) extra = 'correct-opt';
                          else if (idx === arenaSelected) extra = 'wrong-opt';
                        }
                        return (
                          <button
                            key={opt}
                            type="button"
                            disabled={arenaSelected !== null}
                            onClick={() => answerAdaptive(idx)}
                            className={`option-btn animate-stagger ${extra}`}
                            style={{ animationDelay: `${idx * 55}ms` }}
                          >
                            <span className="opt-key">{idx + 1}</span>
                            <span>{opt}</span>
                          </button>
                        );
                      })}
                    </div>

                    {arenaSelected !== null && (
                      <div className="explanation-box animate-fade-up">
                        <p style={{ margin: '0 0 0.7rem' }}>
                          <strong>
                            {arenaSelected === arenaQuestion.correctIndex ? 'Correct!' : 'Incorrect:'}
                          </strong>{' '}
                          {arenaQuestion.explanation}
                        </p>
                        <button type="button" className="btn btn-primary btn-glow" onClick={nextAdaptiveStep}>
                          {arenaRecords.length >= 10 ? 'Finish Adaptive Run' : 'Next Adaptive Question'}
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {!arenaRunning && arenaFinishedAttempt && (
                  <div className="report-hero hero-pass animate-fade-up" style={{ marginTop: '1rem' }}>
                    <div className="row-between">
                      <div>
                        <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: '0.45rem' }}>
                          <CheckCircle2 size={20} /> Adaptive Run Complete
                        </h3>
                        <p style={{ margin: '0.35rem 0 0', opacity: 0.92 }}>
                          Score: <strong>{arenaFinishedAttempt.score} pts</strong> • Accuracy:{' '}
                          <strong>
                            {arenaFinishedAttempt.correctCount}/{arenaFinishedAttempt.totalCount} (
                            {arenaFinishedAttempt.accuracyPercent}%)
                          </strong>{' '}
                          • Best Streak: <strong>{arenaFinishedAttempt.bestStreak}</strong>
                        </p>
                      </div>
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={() => exportAttemptPdf(arenaFinishedAttempt)}
                      >
                        <Download size={14} /> Download PDF
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {tab === 'diagnostics' && (
              <div className="card animate-stage">
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.5rem' }}>
                  <div className="icon-badge gradient-cyan">
                    <BarChart3 size={20} />
                  </div>
                  <div>
                    <h2 style={{ margin: 0 }}>Topic Mastery &amp; Attempt History</h2>
                    <span className="muted" style={{ fontSize: '0.86rem' }}>
                      Combined performance across Topic Assignments and Adaptive Arena runs
                    </span>
                  </div>
                </div>

                <div className="mastery-grid" style={{ marginTop: '1.1rem' }}>
                  {topicStats.map((st, i) => (
                    <div
                      key={st.topic}
                      className={`mastery-card animate-stagger ${getTopicThemeClass(st.topic)}`}
                      style={{ animationDelay: `${i * 75}ms` }}
                    >
                      <div className="row-between">
                        <strong>{st.topic}</strong>
                        <span className="mastery-pct">
                          {st.pct}% ({st.correct}/{st.total})
                        </span>
                      </div>
                      <div className="progress-track">
                        <div className="progress-fill" style={{ width: `${st.pct}%` }} />
                      </div>
                    </div>
                  ))}
                </div>

                <h3 style={{ marginTop: '1.85rem' }}>All Saved Attempts ({history.length})</h3>
                {history.length === 0 ? (
                  <p className="muted">No attempts recorded yet. Complete a Topic Assignment or Adaptive Run!</p>
                ) : (
                  <div className="stack-sm">
                    {history.map((att, idx) => (
                      <div
                        key={att.id}
                        className="history-item animate-stagger"
                        style={{ animationDelay: `${idx * 55}ms` }}
                      >
                        <div>
                          <strong>{att.title}</strong> • <span className="badge badge-indigo">{att.topicFilter}</span>
                          <div className="muted" style={{ fontSize: '0.82rem', marginTop: '0.2rem' }}>
                            {att.completedAt}
                          </div>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                          <span>
                            <strong>{att.score} pts</strong> ({att.accuracyPercent}%)
                          </span>
                          <button
                            type="button"
                            className="btn btn-secondary btn-sm"
                            onClick={() => exportAttemptPdf(att)}
                          >
                            <Download size={14} /> PDF
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {tab === 'builder' && (
              <QuestionBankManager
                existingTopics={topics}
                onAddQuestion={handleAddCustomQuestion}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
