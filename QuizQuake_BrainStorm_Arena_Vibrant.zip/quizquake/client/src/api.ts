import { Question } from './types';
import fallbackQuestions from '../../server/data/questions.json';

const CUSTOM_QUESTIONS_KEY = 'quizquake_custom_questions_v1';

export function loadCustomQuestions(): Question[] {
  try {
    const raw = localStorage.getItem(CUSTOM_QUESTIONS_KEY);
    return raw ? (JSON.parse(raw) as Question[]) : [];
  } catch {
    return [];
  }
}

export function saveCustomQuestion(q: Question): Question[] {
  const next = [q, ...loadCustomQuestions()];
  try {
    localStorage.setItem(CUSTOM_QUESTIONS_KEY, JSON.stringify(next));
  } catch {
    // Ignore storage errors
  }
  return next;
}

export async function fetchAllQuestions(): Promise<Question[]> {
  let base: Question[] = fallbackQuestions as Question[];
  try {
    const res = await fetch('/api/questions');
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data.questions) && data.questions.length > 0) {
        base = data.questions;
      }
    }
  } catch {
    // Fallback to bundled JSON if server is not running
  }
  return [...loadCustomQuestions(), ...base];
}
