@echo off
title QuizQuake - BrainStorm Arena
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required. Install it from https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing project dependencies for the first run...
  call npm install
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
echo Starting QuizQuake. Keep this window open while using the app.
call npm run dev
pause
