import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

const app = express();
const PORT = Number(process.env.PORT) || 4000;

app.use(cors());
app.use(express.json());

const questionsPath = path.join(__dirname, '..', 'data', 'questions.json');

function loadQuestions() {
  const raw = fs.readFileSync(questionsPath, 'utf-8');
  return JSON.parse(raw);
}

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.get('/api/topics', (_req, res) => {
  const questions = loadQuestions();
  const topics = Array.from(new Set(questions.map((q: { topic: string }) => q.topic)));
  res.json({ topics });
});

app.get('/api/questions', (req, res) => {
  let questions = loadQuestions();
  const { topic, difficulty } = req.query;

  if (typeof topic === 'string' && topic !== 'All' && topic.trim() !== '') {
    questions = questions.filter((q: { topic: string }) => q.topic === topic);
  }
  if (typeof difficulty === 'string' && difficulty !== 'All' && difficulty.trim() !== '') {
    questions = questions.filter((q: { difficulty: string }) => q.difficulty === difficulty);
  }

  res.json({ questions });
});

const clientDist = path.join(__dirname, '..', '..', 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(clientDist, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`QuizQuake server listening on http://localhost:${PORT}`);
});
